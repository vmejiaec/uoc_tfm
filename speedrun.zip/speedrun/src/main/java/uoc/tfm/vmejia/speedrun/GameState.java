package uoc.tfm.vmejia.speedrun;

public enum GameState {
    RECRUITING,
    COUNTDOWN,
    LIVE;
}
